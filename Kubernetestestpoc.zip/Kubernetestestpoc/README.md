# kubernetestest
This is a small POC to set Kubernetes cluster using windows docker desktop .
